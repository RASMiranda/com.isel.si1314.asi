--:connect .\one
INSERT INTO asi..ocorrencia (descr, codproduto)
VALUES
		('11112 ocrr D#1', 11112),
		('12346 ocrr D#2', 12346),
		('88885 ocrr C#1', 88885)
;
GO
