--:connect .\two
INSERT INTO asi..ocorrencia (descr, codproduto)
VALUES
		('33333 ocrr C#2', 33333),
		('55554 ocrr C#3', 55554),
		('77775 ocrr C#4', 77775)
;
GO