--:connect .\one
select cod, tipo from asi..produto
select cod from asi..produtoCrianca
select cod from asi..produtoDesp
go