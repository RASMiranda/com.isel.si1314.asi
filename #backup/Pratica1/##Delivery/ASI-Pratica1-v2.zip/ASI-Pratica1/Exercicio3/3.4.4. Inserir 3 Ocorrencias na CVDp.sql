--:connect .\three
INSERT INTO asi..ocorrencia (descr, codproduto)
VALUES
		('66664 ocrr D#3', 66664),
		('90106 ocrr D#4', 90106),
		('92127 ocrr D#5', 92127)
;
GO

