USE [DB2_3]
GO 

DROP SYNONYM [dbo].[insereDisciplina]
GO

DROP SYNONYM [dbo].[deleteDisciplina]
GO

DROP SYNONYM [dbo].[updateDisciplina]
GO

