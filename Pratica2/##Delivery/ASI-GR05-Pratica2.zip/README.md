com.isel.si1314.asi
===================
ISEL MEIC si1314 ASI Grupo 5

===================
Instrucoes:
*  Exercicio 1
	*  Alterar .\00.config_inst conforme o ambiente local
	*  Executar .\Exercicio1\0. run setup inicial.bat
	*  Executar .\Exercicio1\1. realizar failovers.bat
	
*  Exercicio 2
	*  Alterar $\com.isel.si1314.asi\Pratica2\Exercicio2\2.0.config_vars.txt conforme o ambiente local
	*  Executar $\com.isel.si1314.asi\Pratica2\Exercicio2\2.run.all.bat
		*  Executar $\com.isel.si1314.asi\Pratica2\Exercicio2\2.0.run.setup.bat	
		*  Executar $\com.isel.si1314.asi\Pratica2\Exercicio2\2.4-run.setup.LogShiping.bat	
		*  Executar $\com.isel.si1314.asi\Pratica2\Exercicio2\2.a.run.test.bat
		*  Executar $\com.isel.si1314.asi\Pratica2\Exercicio2\2.b.0-setup.LogShiping.CenarioDesastre.bat
		*  Executar $\com.isel.si1314.asi\Pratica2\Exercicio2\2.b.5-run.test.bat
	
*  Exercicio 1
	*  Alterar .\00.config_inst conforme o ambiente local
	*  Executar .\Exercicio3\03.a.run.bat
	
===================
