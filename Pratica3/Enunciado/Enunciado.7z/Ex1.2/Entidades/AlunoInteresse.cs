﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex3.Entidades
{
    public class AlunoInteresse
    {
        public int Numero { get; set; }
        public int Nseq { get; set; }
        public string Interesse { get; set; }

    }
}
